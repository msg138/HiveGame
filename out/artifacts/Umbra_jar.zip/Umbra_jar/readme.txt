Move with WASD
SPace moves up
Shift moves down

3 tools
Pickaxe - Rightclick to place blocks, Leftclick to dig them
Paint brush - Paint an existing block
Eye dropper - get the color of an existing block.

To choose a color click on the color triangle.

press enter or slash to enter chat

Commands -
/new - Create blank landscape to create a model on
/load <modelname>.spv - load an existing model
/save <modelname> - save model into <modelname>.spv file.
/color R G B - set color currently being used.
/sc - shorter for /color
/sens <number> - set the sensitivity, default is 0.002
/mv <number> - set the move speed, default is 0.2